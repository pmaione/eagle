# STM32Bluepill_eagle
eagle library for stm32 bluepill board
