LBR-EX Enhanced Libraries, Scripts, and ULPs for Cadsoft Eagle
==============================================================
This directory contains scripts for use with Cadsoft Eagle PCB.
These files are part of the LBR-EXE enhanced libraries, scripts and
ULP's for Cadsoft Eagle. Please visit http://www.bobstarr.net for
additional information and see the README.PDF documentation for complete
information on using the libraries.
